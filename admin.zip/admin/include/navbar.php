
    <nav>
        <button class="toggle-mob-menu" aria-expanded="false" aria-label="open menu">
            <i class="fa fa-bars"></i>
        </button>
        <a href="../index.html">
            <img class="logo mx-auto" src="../collegeimg/WMSU_SEAL.jpg" alt="ics logo">
        </a>
        <ul class="admin-menu">
            <li class="menu-heading">
                <h3>Admin Functions</h3>
            </li>
            <li>
                <a href="index.php" class="#active">
                    <i class="fa fa-list" aria-hidden="true"><span>Home</span></i>
                </a>
            </li>
            <li>
                <a href="admission_officer.php">
                    <i class="fa fa-list" aria-hidden="true"><span>Admissions</span></i>
                </a>
            </li>
            <li>
                <a href="college.php">
                    <i class="fa fa-list" aria-hidden="true"><span>Colleges</span></i>
                </a>
            </li>
            <li>
                <a href="../index.php?logout='1'">
                    <i class="fa fa-sign-out"><span>logout</span></i>
                </a>
            </li>
        </ul>
    </nav>